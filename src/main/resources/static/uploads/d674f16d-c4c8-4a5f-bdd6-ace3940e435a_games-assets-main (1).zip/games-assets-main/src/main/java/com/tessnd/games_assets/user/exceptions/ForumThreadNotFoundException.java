package com.tessnd.games_assets.user.exceptions;

public class ForumThreadNotFoundException extends RuntimeException{
    public ForumThreadNotFoundException(String message) {
        super(message);
    }
}
