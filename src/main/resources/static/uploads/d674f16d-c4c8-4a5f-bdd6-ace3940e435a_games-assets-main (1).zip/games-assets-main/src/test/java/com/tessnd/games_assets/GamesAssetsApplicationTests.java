package com.tessnd.games_assets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GamesAssetsApplicationTests {

	@Test
	void contextLoads() {
	}

}
