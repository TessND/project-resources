package com.tessnd.games_assets.project.exceptions;

public class ProjectAlreadyExists extends RuntimeException{
    public ProjectAlreadyExists(String message) {
        super(message);
    }
}
