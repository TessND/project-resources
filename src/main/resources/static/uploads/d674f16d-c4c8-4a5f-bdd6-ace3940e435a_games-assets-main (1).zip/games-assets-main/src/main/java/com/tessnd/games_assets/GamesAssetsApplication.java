package com.tessnd.games_assets;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GamesAssetsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GamesAssetsApplication.class, args);
	}

}
